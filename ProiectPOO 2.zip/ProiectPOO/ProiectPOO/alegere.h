#pragma once
#ifndef alegere_H
#define alegere_H
void alegere();
#endif