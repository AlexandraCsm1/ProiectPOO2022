#include "pch.h"
#include "Header.h"
using namespace std;
void alegere() {
	cout << "Alegeti optiunea dorita: \n";
	cout << "1. Incarcare biblioteca dintr-un fisier. \n";
	cout << "2. Creare domeniu nou. \n";
	cout << "3. Adaugare carte la un anumit domeniu. \n";
	cout << "4. Cautare carte in biblioteca. \n";
	cout << "5. Stergere carte din biblioteca. \n";
	cout << "6. Imprumutare / Returnare carte. \n";
	cout << "7. Verificare carti cu termen depasit de imprumut. \n";
	cout << "8. Salvare in fisier a bibliotecii. \n";
	cout << "9. Iesire. \n";



}