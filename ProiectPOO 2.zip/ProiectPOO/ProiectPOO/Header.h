#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <math.h>
#include <stdio.h>
#include <ios>
#include <sstream>
//#include <stdio.h>
//#include <string.h>
#include <cstdio>
#include <stdlib.h>
#include<time.h>
#include "alegere.h"
#include "meniu.h"