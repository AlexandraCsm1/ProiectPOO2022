#pragma once
#ifndef meniu_H
#define meniu_H
void meniu();
//void afisare();
#endif